package app;
import java.rmi.Remote;
import java.rmi.RemoteException;

//descrição dos métodos remotos que o servidor implementa
public interface ICalculadora extends Remote {

    public void registraCliente(IMetodosCliente cli) throws RemoteException;
    
    public double Compra(double valor, int tipo, int tipoconverter) throws RemoteException;

    public double Venda(double valor, int tipo, int tipoconverter) throws RemoteException;
}