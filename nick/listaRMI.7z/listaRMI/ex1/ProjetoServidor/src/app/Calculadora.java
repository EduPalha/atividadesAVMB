package app;

//implementação dos métodos da interface ICalculadora
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Calculadora extends UnicastRemoteObject implements ICalculadora {

    IMetodosCliente meuCliente;//referência do cliente que está acessando esse objeto

    //construtor da classe, obrigatório
    public Calculadora() throws RemoteException {

    }

    //método que o cliente invoca para se registrar no servidor
    @Override
    public void registraCliente(IMetodosCliente cli) throws RemoteException {
        this.meuCliente = cli;
    }

    @Override
    public double Compra(double valor, int tipo, int tipoconverter) throws RemoteException {
        switch (tipo) {
            case 1 -> {
                if (tipoconverter == 2) {
                    valor = valor / 2;
                }
                if (tipoconverter == 2) {
                    valor = valor / 3;
                }
            }
            case 2 -> {
                if (tipoconverter == 1) {
                    valor = valor * 2;
                }
                if (tipoconverter == 3) {
                    valor = valor * 2;
                    valor = valor / 3;
                }
            }
            case 3 -> {
                if (tipoconverter == 1) {
                    valor = valor * 3;
                }
                if (tipoconverter == 2) {
                    valor = valor * 3;
                    valor = valor / 2;
                }
            }
            default -> {
            }
        }

        return valor;
    }

    @Override
    public double Venda(double valor, int tipo, int tipoconverter) throws RemoteException {
         switch (tipo) {
            case 1 -> {
                if (tipoconverter == 2) {
                    valor = valor * 2;
                }
                if (tipoconverter == 2) {
                    valor = valor * 3;
                }
            }
            case 2 -> {
                if (tipoconverter == 1) {
                    valor = valor / 2;
                }
                if (tipoconverter == 3) {
                    valor = valor / 2;
                    valor = valor * 3;
                }
            }
            case 3 -> {
                if (tipoconverter == 1) {
                    valor = valor / 3;
                }
                if (tipoconverter == 2) {
                    valor = valor / 3;
                    valor = valor * 2;
                }
            }
            default -> {
            }
        }

        return valor;
    }

}
