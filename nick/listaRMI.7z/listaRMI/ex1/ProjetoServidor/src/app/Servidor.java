package app;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Servidor {
    public static void main(String[] args) {
        
        try {
            //inicializa o RMI
            LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
            //instancia e registra o objeto remotamente
            Calculadora c = new Calculadora();            
            Naming.bind("rmi://localhost/Calculadora", c); 
            
        } catch (RemoteException ex) {
            System.out.println("Erro na criação da calculadora");
        } catch (AlreadyBoundException ex) {
            System.out.println("Objeto já registrado");
        } catch (MalformedURLException ex) {
            System.out.println("URL mal formada");
        }
        
    }
}
