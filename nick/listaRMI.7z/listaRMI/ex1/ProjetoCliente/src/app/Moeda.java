
package app;

import java.io.Serializable;

public class Moeda implements Serializable {
    
    public Moeda(double Valor){
        quantia = Valor;
    }
    
    public int Tipo;
    
    public double quantia;
    
    public int TipoConversao;
    
    public int Acao;
    
}
