package app;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) {

        Moeda Moeda = new Moeda(1000);

        try {
            Scanner ler = new Scanner(System.in);

            MetodosCliente meusMetodos = new MetodosCliente();

            ICalculadora calc = (ICalculadora) Naming.lookup("rmi://localhost/Calculadora");

            calc.registraCliente(meusMetodos);

            MostrarMoedas(Moeda);

            System.out.println("Escolha o Tipo de Moeda que voce usa\n 1 real\n 2 dolar\n 3 euro");
            Moeda.Tipo = ler.nextInt();

            System.out.println("Escolha uma Acao \n 1 Comprar \n 2 vender");
            Moeda.Acao = ler.nextInt();

            System.out.println("Agora Digite o Valor");
            Moeda.quantia = ler.nextDouble();

            System.out.println("Escolha o Tipo de Moeda que seu negociante usa\n 1 real\n 2 dolar\n 3 euro");
            Moeda.TipoConversao = ler.nextInt();
            if (Moeda.Acao == 1) {
                Moeda.quantia = calc.Compra(Moeda.quantia, Moeda.Tipo, Moeda.TipoConversao);
                MostrarMoedas(Moeda);
            } else {
                Moeda.quantia = calc.Venda(Moeda.quantia, Moeda.Tipo, Moeda.TipoConversao);
                MostrarMoedas(Moeda);
            }
        } catch (NotBoundException ex) {
            System.out.println("Nenhum objeto encontrado na URL");
        } catch (MalformedURLException ex) {
            System.out.println("URL malformada");
        } catch (RemoteException ex) {
            System.out.println("Erro de comunicação");
        }
    }

    public static void MostrarMoedas(Moeda Moeda) {
        System.out.println("Voce tem " + Moeda.quantia + " em dinheiro");
    }

}
