package app;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class MetodosCliente extends UnicastRemoteObject implements IMetodosCliente{

    public MetodosCliente() throws RemoteException{
    }

    @Override
    public void enviaResultado(double res) throws RemoteException {
        System.out.println("Chegou o resultado do servidor = "+res);
    }
    
}
