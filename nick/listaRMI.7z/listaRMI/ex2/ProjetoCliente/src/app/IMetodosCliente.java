
package app;

import java.rmi.Remote;
import java.rmi.RemoteException;

//descreve os métodos que o servidor pode invocar no cliente
public interface IMetodosCliente extends Remote {

    public void enviaResultado(double res) throws RemoteException;
}
