package app;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) {

        try {
            Scanner ler = new Scanner(System.in);
            int Numero = 0;
            MetodosCliente meusMetodos = new MetodosCliente();

            IOperacoesBanco Banco = (IOperacoesBanco) Naming.lookup("rmi://localhost/Banco");

            Banco.registraCliente(meusMetodos);

            double Saldo = 0;
            Boolean sair = false;

            System.out.println("Bem Vindo ao Banco! \n O que deseja fazer? \nDigite: \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");

            while (!sair) {
                Numero = ler.nextInt();
                double ValorOperacao = 0;
                switch (Numero) {
                    case 0:
                        sair = true;
                    case 1:
                        System.out.println("Digite o valor que deseja depositar");
                        ValorOperacao = ler.nextDouble();
                        System.out.println("Depositou: " + ValorOperacao + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                        Banco.Depositar(ValorOperacao);
                        break;
                    case 2:
                        System.out.println("Digite o valor que deseja sacar");
                        ValorOperacao = ler.nextDouble();
                        System.out.println("Sacou: " + ValorOperacao + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                        Banco.Sacar(ValorOperacao);
                        break;
                    case 3:
                        Saldo = Banco.RetornarSaldo();
                        System.out.println("Saldo: " + Saldo + "\nEscolha a nova Operacao \n 0 para sair \n 1 para deposito \n 2 para saque \n 3 para consultar o saldo");
                        break;

                    default:
                        System.out.println("O numero digitado nao equivale a uma operacao");
                        break;
                }
            }

        } catch (NotBoundException ex) {
            System.out.println("Nenhum objeto encontrado na URL");
        } catch (MalformedURLException ex) {
            System.out.println("URL malformada");
        } catch (RemoteException ex) {
            System.out.println("Erro de comunicação");
        }
    }

}
