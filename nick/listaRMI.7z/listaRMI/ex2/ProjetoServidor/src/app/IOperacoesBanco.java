package app;

import java.rmi.Remote;
import java.rmi.RemoteException;

//descrição dos métodos remotos que o servidor implementa
public interface IOperacoesBanco extends Remote {

    public void registraCliente(IMetodosCliente cli) throws RemoteException;

    public void Sacar(double x) throws RemoteException;

    public void Depositar(double x) throws RemoteException;

    public double RetornarSaldo() throws RemoteException;

}
