package app;

//implementação dos métodos da interface ICalculadora

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

public class OperacoesBanco extends UnicastRemoteObject implements IOperacoesBanco{

    IMetodosCliente meuCliente;//referência do cliente que está acessando esse objeto
      
    double Saldo;
    
    //construtor da classe, obrigatório
    public OperacoesBanco() throws RemoteException{
        
    }
    
    //método que o cliente invoca para se registrar no servidor
    @Override
    public void registraCliente(IMetodosCliente cli) throws RemoteException {
        this.meuCliente = cli;
    }
    
    @Override
    public void Sacar(double x) throws RemoteException {
        this.Saldo = this.Saldo - x;
    }

    @Override
    public void Depositar(double x) throws RemoteException {
        this.Saldo = this.Saldo + x;
    }

    @Override
    public double RetornarSaldo() throws RemoteException {
        return this.Saldo;
    }




}
